import {React, useEffect, useState} from 'react';
import './admin.css';
import {Link} from 'react-router-dom';

/**
 * Componente admin
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function Admin(props) {
    const [usuariosSolicitud, setUsuariosSolicitud] = useState([]);
    const [usuarios, setUsuarios] = useState([]);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');
    const [surname, setSurname] = useState('');
    const [email, setEmail] = useState('');

    useEffect(() => {
        fetchUsuariosSolicitud();
        fetchUsuarios();
    }, []);

    function fetchUsuariosSolicitud() {
        fetch(props.url+'/api/usuariosSolicitud')
        .then(response => response.json())
        .then(data => {
            setUsuariosSolicitud(data);

        })
        .catch(error => console.log(error));
    }

    function fetchUsuarios() {
        fetch(props.url+'/api/usuarios')
        .then(response => response.json())
        .then(data => {
            setUsuarios(data);
        })
        .catch(error => console.log(error));
    }

    function handleSubmit(event) {
        event.preventDefault();
        fetch(props.url+'/api/registerAdmin/'+email+'/'+name+'/'+surname+'/'+password+'/'+username)
        .then(response => response.json())
        .then(data => {
            alert('Usuario creado');
        })
    }

    function acceptUser(id) {
        fetch(props.url+'/api/acceptUsuarioRegister/' + id)
        .then(response => response.json())
        .then(data => {
            alert('Usuario aceptado');
        })
    }

    function rejectUser(id) {
        fetch(props.url+'/api/rejectUsuarioRegister/' + id)
        .then(response => response.json())
        .then(data => {
            alert('Usuario rechazado');
        })
    }

    function deleteUser(id) {
        fetch(props.url+'/api/deleteUsuario/' + id)
        .then(response => response.json())
        .then(data => {
            alert('Usuario eliminado');
        })
    }

    return (
        <>
            <div className='admin__container'>
                <div className='usuariosSolicitud__admin'>
                    <h2>Usuarios en solicitud</h2>
                    <details>
                    <summary></summary>
                        <div className='usuariosSolicitud__admin__container'>
                        {usuariosSolicitud.map((usuario, index) => {
                            return (
                                <div className='usuariosSolicitud__admin__container__usuario' key={index}>
                                    <p>Usuario: {usuario.usuario}</p>
                                    <p>Contraseña: {usuario.contraseña}</p>
                                    <p>Correo: {usuario.correo}</p>
                                    <p>Nombre: {usuario.nombre}</p>
                                    <p>Apellidos: {usuario.apellidos}</p>
                                    <div className='usuariosSolicitud__admin__container__usuario__buttons'>
                                        <button onClick={() => {acceptUser(usuario.id)}}>Aceptar</button>
                                        <button onClick={() => {rejectUser(usuario.id)}}>Rechazar</button>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                    </details>
                </div>

                <div className='usuarios__admin'>
                    <h2>Usuarios existentes</h2>
                    <details>
                        <summary></summary>
                        <div className='usuariosSolicitud__admin__container'>
                            {usuarios.map((usuario, index) => {
                                return (
                                    <div className='usuariosSolicitud__admin__container__usuario' key={index}>
                                        <p>Usuario: {usuario.usuario}</p>
                                        <p>Contraseña: {usuario.contraseña}</p>
                                        <p>Correo: {usuario.correo}</p>
                                        <p>Nombre: {usuario.nombre}</p>
                                        <p>Apellidos: {usuario.apellidos}</p>
                                        <div className='usuariosSolicitud__admin__container__usuario__buttons'>
                                            <button onClick={() => {deleteUser(usuario.id);}}>Eliminar</button>
                                        </div>
                                    </div>
                                )
                            })}
                        </div>
                    </details>
                </div>

                <div className='insert_usuario__admin'>
                    <h2>Insertar usuario</h2>
                    <details>
                        <summary></summary>
                        <div className='insert_usuario__admin__container'>
                            <form onSubmit={handleSubmit} className='formLogin'>
                                <div className='divInputLogin'>
                                    <div className="form-floating inputLogin">
                                    <input required type="text" className="form-control" id="floatingName" placeholder="Password" value={name} onChange={(event) => setName(event.target.value)}/>
                                    <label htmlFor="floatingPassword">Nombre</label>
                                    </div>
                                </div>

                                <div className='divInputLogin'>
                                    <div className="form-floating inputLogin">
                                    <input required type="text" className="form-control" id="floatingSurname" placeholder="Password" value={surname} onChange={(event) => setSurname(event.target.value)}/>
                                    <label htmlFor="floatingPassword">Apellidos</label>
                                    </div>
                                </div>

                                <div className='divInputLogin'>
                                    <div className="form-floating inputLogin">
                                    <input required type="email" className="form-control" id="floatingEmail" placeholder="Password" value={email} onChange={(event) => setEmail(event.target.value)}/>
                                    <label htmlFor="floatingPassword">Correo electrónico</label>
                                    </div>
                                </div>

                                <div className='divInputLogin'>
                                    <div className="form-floating inputLogin">
                                    <input required type="text" className="form-control" id="floatingInput" placeholder="name@example.com" value={username} onChange={(event) => setUsername(event.target.value)}/>
                                    <label htmlFor="floatingInput">Usuario</label>
                                    </div>
                                </div>
                                
                                <div className='divInputLogin'>
                                    <div className="form-floating inputLogin">
                                    <input required type="password" className="form-control" id="floatingPassword" placeholder="Password" value={password} onChange={(event) => setPassword(event.target.value)}/>
                                    <label htmlFor="floatingPassword">Contraseña</label>
                                    </div>
                                </div>

                                <button onClick={handleSubmit} type="submit" className='loginButton'><img src='/assets/loginButton.png' className='loginButtonImg'/></button>
                            </form>
                        </div>
                    </details>
                </div>

            </div>
        </>
    );
}
  
export default Admin;