import {React, useEffect, useState} from 'react';
import {Link} from 'react-router-dom';
import './rankingConcurso.css';

/**
 * Div rápido para mostrar el ranking de un concurso
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function RankingConcurso(props) {
    const [listaRanking, setListaRanking] = useState([]);
    const [totalFilas, setTotalFilas] = useState(0);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        peticion();
    }, []);

    /**
     * Pide al servidor el ranking de usuarios
     */
    function peticion() {
        fetch(props.urlPeticion)
        .then(res => res.json())
        .then(data => {
            if (data.length > 0) {
                setListaRanking(data);
                setTotalFilas(data[0].total_filas);
            } else {
                setListaRanking([]);
                setTotalFilas('Proximamente');
            }
            setIsLoading(false);
        })
    }

    /**
     * Devuelve el tiempo que ha pasado desde la fecha que le pasamos
     * @param {String} fecha 
     * @returns {String}
     */
    function calcularTiempo(fecha) {
        // función que calcula el tiempo que ha pasado desde la última publicación
        let fechaActual = new Date();
        let fechaPublicacion = new Date(fecha);
        let diferencia = fechaActual.getTime() - fechaPublicacion.getTime();
        // si la diferencia es menor a 1 minuto, se devuelve hace un momento si no, se devuelve hace x minutos o x horas o x días o x meses o x años
        if(diferencia < 60000) {
            return 'hace un momento';
        } else if(diferencia < 3600000) {
            return 'hace un momento';
        } else if(diferencia < 86400000) {
            return 'hace un momento';
        } else if(diferencia < 2592000000) {
            return 'hace ' + Math.floor(diferencia / 86400000) + ' días';
        } else if(diferencia < 31536000000) {
            return 'hace ' + Math.floor(diferencia / 2592000000) + ' meses';
        } else {
            return 'hace ' + Math.floor(diferencia / 31536000000) + ' años';
        }
    }

    /**
     * Efecto de carga mientras se obtiene el ranking
     */
    if(isLoading) return (
        <>
            <div className='ranking'>
                <h1 className='cargando'>Ranking</h1>
                <div className="podio cargando">
                </div>
                <div>
                    <p className='cargando'>Hay un total de </p>
                    <p className='totalFilas cargando'>Cargando...</p>
                    <p className='cargando'>petardos fumados</p>
                </div>
                <div className="lista">
                    {
                            <div className='usuarioRanking cargando'>
                                0 - 
                                <div className='divFotoPerfil'></div>
                                Cargando...
                                <b className='totalPuntuacion cargando'>Cargando...</b>
                                <p className='ultimoHace cargando'>Cargando...</p>
                            </div>
                    }
                </div>
            </div>
        </>
    )

    return (
        <>
            
                <div className='ranking rankingConcursoDiv'>
                    <Link className="enlaceLink" to={listaRanking.length > 0 ? '/rankingConcurso' : '/novedades'}>
                    <h1 className='tituloRankingConcurso'>Concurso Abril</h1>
                    </Link>
                    <div>
                        {
                            listaRanking.length > 0 ? <p><b>Hay un total de </b></p> : ''
                        }
                        <p className='totalFilas'>{totalFilas}</p>
                        {
                            listaRanking.length > 0 ? <p><b>Petardos fumados</b></p> : <Link className="enlaceLink" to='/novedades'><p><b>Pulse para más información</b></p></Link>
                        }
                    </div>
                
                    <div className="lista">
                        {
                            listaRanking.map((usuario, index) => {
                                return <div className='usuarioRanking' key={index}>
                                    {index + 1}- 
                                    <Link to={"/perfil/"+usuario.id_usuario}>
                                        <div className='divFotoPerfil'><img src={usuario.imagenPerfil} className='imagenPerfilRanking'/></div>
                                    </Link>
                                    <span className='usuarioNombreRanking'>{usuario.nombre}</span>
                                    <b className='totalPuntuacion'>{usuario.puntuacion}</b>
                                </div>
                            })
                        }
                    </div>
                </div>
            
        </>
    );
}
  
export default RankingConcurso;