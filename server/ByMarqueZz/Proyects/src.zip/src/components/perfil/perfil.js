import {React, useEffect, useState} from 'react';
import './perfil.css';
import HeaderPerfil from './headerPerfil/headerPerfil';
import HeaderInfo from './headerInfo/headerInfo';
import Publicaciones from './publicaciones/publicaciones';

/**
 * Componente perfil, se encarga de mostrar el perfil de un usuario
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function Perfil(props) {
    const [user, setUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    /**
     * Obtiene el usuario que se quiere ver
     */
    function settingUser() {
        let url = window.location.href;
        let id = url.split('/')[4];
        fetch(props.url+'/api/getUser/' + id) 
        .then((response) => response.json())
        .then((data) => {
            setUser(data);
            setIsLoading(false);
        });
        
    }

    /**
     * Cambia el color de fondo de la página
     */
    function setMainBackground() {
        document.getElementsByClassName('main')[0].style.background = 'white';
      }

    useEffect(() => {
        setMainBackground();
        settingUser();
    }, []);

    /**
     * Mientras se carga el usuario se muestra un div vacío
     */
    if(isLoading) {
        return (
            <>
                <div className='perfil'>
                    
                </div>
            </>
        )
    }

    return (
        <>
            <div className='perfil'>
                <HeaderPerfil url={props.url} user={user[0]}/>
                <HeaderInfo url={props.url} user={user[0]} userLogged={props.user}/>
                <Publicaciones url={props.url} user={user[0]}/>
            </div>
            
        </>
    );
}
  
export default Perfil;