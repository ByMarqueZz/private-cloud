import {React, useEffect, useState} from 'react';
import './headerPerfil.css';

/**
 * Componente headerPerfil, se encarga de mostrar la cabecera del perfil con 
 * la foto de perfil, el nombre de usuario, y las estadísticas
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function HeaderPerfil(props) {
    const [dataPublicaciones, setDataPublicaciones] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {getInfoPerfil()}, []);

    /**
     * Obtiene la información del usuario para mostrar en la cabecera
     */
    function getInfoPerfil() {
        fetch(props.url+'/api/datosHeaderPerfil/' + props.user.id)
        .then((response) => response.json())
        .then((data) => {
            setDataPublicaciones(data);
            setIsLoading(false);
        })
    }

    /**
     * Efecto de carga mientras se obtiene la información del usuario
     */
    if (isLoading) {
        return (
            <>
            <div className='headerPerfil'>
                <div className='headerPerfil__foto_div cargando'></div>
                <p className='cargando'>Cargando...</p>
                <div className='headerStats'>
                    <div className='headerStats__publicaciones'>
                        <div className='headerStats__publicaciones__numero cargando'>Cargando...</div>
                        <div className='cargando'>Publicaciones</div>
                    </div>
                    <div className='headerStats__publicaciones'>
                        <div className='headerStats__publicaciones__numero cargando'>Cargando...</div>
                        <span className='cargando'>Seguidores</span>
                    </div>
                    <div className='headerStats__publicaciones'>
                        <div className='headerStats__publicaciones__numero cargando'>Cargando...</div>
                        <span className='cargando'>Siguiendo</span>
                    </div>
                </div>
            </div>
        </>
        )
    }

    return (
        <>
            <div className='headerPerfil'>
                <div className='headerPerfil__foto_div'><img src={props.user.foto_perfil} className='headerPerfil__foto'/></div>
                <p>{props.user.usuario}</p>
                <div className='headerStats'>
                    <div className='headerStats__publicaciones'>
                        <div className='headerStats__publicaciones__numero'>{dataPublicaciones[0] ? dataPublicaciones[0].datos : 0}</div>
                        <div>Publicaciones</div>
                    </div>
                    <div className='headerStats__publicaciones'>
                        <div className='headerStats__publicaciones__numero'>{dataPublicaciones[2] ? dataPublicaciones[2].datos : 0}</div>
                        <span>Seguidores</span>
                    </div>
                    <div className='headerStats__publicaciones'>
                        <div className='headerStats__publicaciones__numero'>{dataPublicaciones[1] ? dataPublicaciones[1].datos : 0}</div>
                        <span>Siguiendo</span>
                    </div>
                </div>
            </div>
        </>
    );
}
  
export default HeaderPerfil;