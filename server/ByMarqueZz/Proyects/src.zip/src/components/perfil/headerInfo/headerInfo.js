import {React, useEffect, useState} from 'react';
import './headerInfo.css';
import {useNavigate} from 'react-router-dom';

/**
 * Componente con la información del usuario sobre el nombre, descripción, 
 * y los botones de seguir y enviar mensaje o cerrar sesión y editar perfil
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function HeaderInfo(props) {
    const [infoUser, setInfoUser] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [leSigue, setLeSigue] = useState('Seguir');
    const navigate = useNavigate();

    useEffect(() => {getInfoUser()}, []);

    /**
     * Peticion para obtener la información del usuario
     */
    function getInfoUser() {
        fetch(props.url+'/api/datosHeaderInfo/' + props.user.id + '/' + props.userLogged.id)
        .then((response) => response.json())
        .then((data) => {
            setInfoUser(data[0]);
            if (data[0].seguidor != null) {
                setLeSigue('Dejar de seguir');
            }
            setIsLoading(false);
        })
    }

    /**
     * Se encarga de seguir o dejar de seguir al usuario
     */
    function seguirUsuario() {
        fetch(props.url+'/api/seguirUsuario/' + props.user.id + '/' + props.userLogged.id)
        .then((response) => response.json())
        .then((data) => {
            setLeSigue(data);
        })
    }

    /**
     * Cierra la sesión del usuario
     */
    function cerrarSesion() {
        document.cookie = 'id=; Max-Age=-99999999;';
        window.location.href='/';
    }

    /**
     * Efecto cargando mientras se carga la información del usuario
     */
    if (isLoading) {
        return (
            <>
                <div className='headerInfo'>
                    <div className='headerInfo__nombre cargando'>Nombre:</div>
                    <div className='headerInfo__decripcion cargando'>Descripción:</div>
                </div>
                <div className='headerInfo__botonEditarPerfil'>
                    <button className='btn btn-outline-success cargando'>Editar Perfil</button>
                    <button className='btn btn-outline-success cargando'>Cerrar Sesión</button>
                </div>
                <hr/>
            </>
        )
    }

    return (
        <>
            <div className='headerInfo'>
                <div className='headerInfo__nombre'>Nombre: {infoUser.nombre+' '+infoUser.apellidos}</div>
                <div className='headerInfo__decripcion'>Descripción: {infoUser.descripcion}</div>
            </div>
            <div className='headerInfo__botonEditarPerfil'>
                {
                    props.user.id == props.userLogged.id ? <button className='btn btn-outline-success' onClick={cerrarSesion}>Cerrar Sesión</button> : <button className='btn btn-outline-success'>Enviar Mensaje</button>
                }
                {
                    props.user.id == props.userLogged.id ? <button className='btn btn-outline-success'>Editar Perfil</button> : <button className='btn btn-outline-success' onClick={seguirUsuario}>{leSigue}</button>
                }
            </div>
            <hr/>
        </>
    );
}
  
export default HeaderInfo;