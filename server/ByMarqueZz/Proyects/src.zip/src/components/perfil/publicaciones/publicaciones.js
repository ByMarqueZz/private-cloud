import {React, useEffect, useState} from 'react';
import './publicaciones.css';
import Publicacion from './publicacion/publicacion';

/**
 * Componente publicaciones es un div que contiene las publicaciones de un usuario
 * pero solo las fotos que son un enlace a la publicación
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function Publicaciones(props) {
    const [publicaciones, setPublicaciones] = useState([]);
    const [publicacionesMostrar, setPublicacionesMostrar] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [noMore, setNoMore] = useState(false);

    useEffect(() => {
        getInfoUser();
    }, []);

    /**
     * Obtiene las publicaciones del usuario
     */
    function getInfoUser() {
        fetch(props.url+'/api/historial/' + props.user.id)
        .then((response) => response.json())
        .then((data) => {
            setPublicaciones(data);
            if (data.length > 6) {
                setPublicacionesMostrar(data.slice(0, 6));
            } else {
                setPublicacionesMostrar(data);
                setNoMore(true);
            }
            setIsLoading(false);
        })
    }

    /**
     * Carga más publicaciones
     */
    function cargarMas() {
        if (publicacionesMostrar.length < publicaciones.length) {
            if(publicacionesMostrar.length + 6 < publicaciones.length) {
                setPublicacionesMostrar(publicaciones.slice(0, publicacionesMostrar.length + 6));
            } else {
                setNoMore(true);
                setPublicacionesMostrar(publicaciones);
            }
        } else {
            setNoMore(true);
        }
    }

    /**
     * Efecto de carga mientras se obtiene las publicaciones del usuario
     */
    if (isLoading) {
        return <div  className='divPublicaciones'>
                <div className='publicacionDiv cargando'></div>
                <div className='publicacionDiv cargando'></div>
                <div className='publicacionDiv cargando'></div>
                <div className='publicacionDiv cargando'></div>
                <div className='publicacionDiv cargando'></div>
                <div className='publicacionDiv cargando'></div>
            </div>
    }
    
    /**
     * Si no hay más publicaciones que mostrar, no se muestra el botón de cargar más
     */
    if (noMore) {
        return (
            <>
                <div className='divPublicaciones'>
                    {
                        publicacionesMostrar.map((publicacion, index) => {
                            return (<Publicacion data={publicacion} key={index}/>)
                        })
                    }
                </div>
            </>
        );
    }

    return (
        <>
            <div className='divPublicaciones'>
                {
                    publicacionesMostrar.map((publicacion, index) => {
                        return (<Publicacion data={publicacion} key={index}/>)
                    })
                }
            </div>
            <div className='btnCargasMasPerfil'>
                <button className='btn btn-outline-success' onClick={cargarMas}>Cargar más</button>
            </div>
        </>
    );
}
  
export default Publicaciones;