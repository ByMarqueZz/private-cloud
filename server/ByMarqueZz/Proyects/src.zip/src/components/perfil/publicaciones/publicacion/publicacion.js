import {React, useEffect, useState} from 'react';
import './publicacion.css';
import { Link } from "react-router-dom";

/**
 * Componente publicacion es una foto que es un enlace a la publicacion
 * @param {Object} param0 
 * @returns {JSX.Element}
 */

function Publicacion({data}) {
    if (data.firestore != null) {
        return (
            <>
            <Link to={"/publicacion/"+data.id_publicacion}>
                <div className='publicacionDiv'>
                    <img src={data.foto} className='publicacionImg'/>
                </div>
            </Link>
            </>
        )
    }
    return (
        <>
            <Link to={"/publicacion/"+data.id_publicacion}>
                <div className='publicacionDiv'>
                    <img src={'/uploaded/'+data.usuario+'/publicaciones/'+data.foto} className='publicacionImg'/>
                </div>
            </Link>
        </>
    );
}
  
export default Publicacion;