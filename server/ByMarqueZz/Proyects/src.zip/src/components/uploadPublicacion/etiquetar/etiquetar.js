import {React, useEffect, useState} from 'react';
import './etiquetar.css';

/**
 * Componente etiquetar, se encarga de mostrar las personas que puedes etiquetar
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function Etiquetar(props) {
    const [personas, setPersonas] = useState([]);
    const [personasMostrar, setPersonasMostrar] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        getPersonas();
    }, []);

    /**
     * Filtra las personas que coinciden con el texto introducido
     * con el nombre de usuario de las personas que sigue
     * @param {Event} event 
     */
    function search(event) {
        let personasFiltradas = personas.filter(persona => persona.usuario.toLowerCase().includes(event.target.value.toLowerCase()));
        setPersonasMostrar(personasFiltradas);
    }

    /**
     * Obtiene las personas que sigue el usuario
     */
    function getPersonas() {
        fetch(props.url + '/api/getPersonasEtiquetar/' + props.user.id)
        .then((response) => response.json())
        .then((data) => {
            setPersonas(data);
            setPersonasMostrar(data);
            setIsLoading(false);
        })
        .catch((error) => console.error(error));
    }
    
    return (
        <>
            <div className='etiquetarPersonasDiv'>
                <div className='etiquetarPersonasTextoDiv'>
                    <h5><b>Etiquetar personas:</b></h5>
                    <span>Ahora puedes etiquetar personas para fumarte un porro a medias. Solo puedes etiquetar a gente que sigues</span>
                </div>
                <div className='etiquetarPersonasSelectDiv'>
                <div className="dropdown">
                    <a className="btn dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        {props.selectedPersonas ? <div><img src={props.selectedPersonas.foto_perfil} className="imagenOptionEtiquetados"/>{props.selectedPersonas.usuario}</div> : 'Nadie'}
                    </a>

                    <ul className="dropdown-menu">
                        <li><input className='dropdown-item inputSearchEtiquetar' type='text' placeholder='Buscar...' onChange={search}/></li>
                        <li><a className="dropdown-item" onClick={() => {props.setSelectedPersonas(null)}}>No etiquetar a nadie</a></li>
                        {
                            isLoading ? <li key="loading"><a className="dropdown-item">Cargando...</a></li> : personasMostrar.map((persona, index) => {
                                if(index > 3) return;
                                return <li key={index}><a className="dropdown-item divTextEtiquetados" onClick={
                                        () => {props.setSelectedPersonas(persona)}
                                    }>
                                        <img src={persona.foto_perfil} className="imagenOptionEtiquetados"/>
                                        {persona.usuario}
                                    </a></li>
                            })
                        }
                    </ul>
                </div>
                </div>
            </div> 
        </>
    );
}
  
export default Etiquetar;