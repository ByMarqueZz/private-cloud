import {React, useState, useEffect} from 'react';
import './uploadPublicacion.css';
import HeaderUpload from './headerUpload/headerUpload';
import Etiquetar from './etiquetar/etiquetar';
import Enviar from './enviar/enviar';
import { initializeApp } from "firebase/app";
import { getStorage, ref, getDownloadURL, uploadBytes } from "firebase/storage";
import Spotify from '../spotify/spotify';

/**
 * Vista para subir una publicación
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function Upload(props) {
  const [file, setFile] = useState(null);
  const [selectedPersonasToEtiquetar, setSelectedPersonasToEtiquetar] = useState(null);
  const [selectedPersonasToEnviar, setSelectedPersonasToEnviar] = useState(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const [selectedSong, setSelectedSong] = useState(null);

  const firebaseConfig = {
    apiKey: "AIzaSyA4QRj_48JCx8mTJDAuMumhrpg50L1qyz4",
    authDomain: "joints-counter.firebaseapp.com",
    projectId: "joints-counter",
    storageBucket: "joints-counter.appspot.com",
    messagingSenderId: "979765557331",
    appId: "1:979765557331:web:3d6da6eb530843e490aea6"
  };
  const app = initializeApp(firebaseConfig);
    const storage = getStorage(app);

  useEffect(() => {
    setMainBackground();
  }, []);

  /**
   * Obtiene el archivo seleccionado por el usuario para subir y lo muestra en la vista
   * @param {Event} event 
   */
  const handleFileChange = (event) => {
      setFile(event.target.files[0]);
      var preview = event.target.parentNode.querySelector('.file-preview');
      var file = event.target.files[0];
      var reader = new FileReader();

      reader.onloadend = function() {
          preview.innerHTML = '<img src="' + reader.result + '" class="filePreviewImg">';
      }

      if (file) {
          reader.readAsDataURL(file);
      } else {
          preview.innerHTML = '<i className="fas fa-plus"></i>';
      }
  };

  /**
   * Envia el archivo al servidor para que se suba
   * como publicación. Antes de eso lo comprime en 800x600
   * para que pese menos. Luego comprueba si hay personas etiquetadas
   * o para compartir la publicación y las envía al servidor
   * @returns 
   */
  function handleSubmit() {
    if (file == null) {
      return;
    }

    function isUpdatingStyle() {
      document.body.style.opacity = 0.2;
    }

    function revertIsUpdatingStyle() {
      document.body.style.opacity = 1;
    }
  
    let fileName = new Date().getTime() + file.name
    uploadBytes(ref(storage, fileName), file).then((snapshot) => {
      setIsUpdating(true)
      isUpdatingStyle()
      console.log('Uploaded a blob or file!');
      console.log(snapshot)
      let form = document.getElementById("headerUploadForm");
      let descripcion = document.getElementById("headerUploadDescripcion");

      // form.submit();

      const formData = new FormData();
      formData.append("fileName", fileName);

      if (descripcion.value !== "") {
        formData.append("description", descripcion.value);
      }

      if (selectedPersonasToEtiquetar != null) {
        formData.append("etiquetar", selectedPersonasToEtiquetar.id);
      }

      if (selectedPersonasToEnviar != null) {
        let mensaje = document.getElementById("mensajeParaCompartirUpload");
        if (mensaje.value !== "") {
          formData.append("mensaje", mensaje.value);
        }
        formData.append("enviar", selectedPersonasToEnviar.id);
      }

      fetch(props.url+"/api/upload/" + props.user.usuario + '/' + props.user.id, {
        method: "POST",
        body: formData})
      .then((response) => response.json())
      .then((data) => {
        console.log(data)
        setIsUpdating(false)
        revertIsUpdatingStyle()
        window.location.href = 'https://www.jointscounter.com'
      })
      .catch((error) => {
        console.error(error);
        setIsUpdating(false)
        revertIsUpdatingStyle()
        // alert("Error al subir la publicación"+error)
        window.location.href = 'https://www.jointscounter.com'
      });
      revertIsUpdatingStyle()
    });
      
    
  }

    /**
     * Pinta el archivo seleccionado en la vista
     * @param {String} dataurl 
     * @param {String} filename 
     * @returns {File}
     */
    function dataURLtoFile(dataurl, filename) {
      var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
          bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
      while(n--){
          u8arr[n] = bstr.charCodeAt(n);
      }
      return new File([u8arr], filename, {type:mime});
    }

    /**
     * Cambia el color de fondo de la vista
     */
    function setMainBackground() {
      document.getElementsByClassName('main')[0].style.background = 'white';
    }

    return (
        <>
            <div className='uploadPublicacionDiv'>
            <h1>Subida de publicaciones</h1>
                <HeaderUpload handleFileChange={handleFileChange}/>
                <Etiquetar user={props.user} url={props.url} selectedPersonas={selectedPersonasToEtiquetar} setSelectedPersonas={setSelectedPersonasToEtiquetar}/>
                <Spotify setSelectedSong={setSelectedSong} isUploading={true} user={props.user} url={props.url} search={'Perfect girl'} token={props.token} />
                {
                  //<Enviar user={props.user} url={props.url} selectedPersonas={selectedPersonasToEnviar} setSelectedPersonas={setSelectedPersonasToEnviar}/>
                }
            </div>
            <button className="btn btn-outline-secondary" onClick={handleSubmit}>Publicar</button>
            {
              isUpdating ? <img src='/assets/cargando.gif' className='loading-logo-upload'></img>
             : ''
            }
        </>
    );
}
  
export default Upload;