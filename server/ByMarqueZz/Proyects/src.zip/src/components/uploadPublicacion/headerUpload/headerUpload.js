import {React} from 'react';
import './headerUpload.css';

/**
 * Componente donde se muestra el div para añadir foto
 * y la descripción de la publicación
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function HeaderUpload(props) {
    
    return (
        <>
            <div className='headerUploadDiv'>
                <div className='headerUploadImageDiv'>
                    <form id="headerUploadForm">
                        <div className="file-upload">
                            <label htmlFor="file-input">
                                <div className="file-preview">
                                    <img src="/assets/boton-circular-plus.png" className='fotoAddPhotoUpload' alt='+'/>
                                </div>
                            </label>
                            <input id="file-input" type="file" onChange={props.handleFileChange} required/>
                        </div>
                        <input type="text" name="descripcion" id="headerUploadDescripcion" placeholder="Escribe una descripción" className='headerUploadDescripcion'/>
                    </form>
                </div>
            </div>
        </>
    );
}
  
export default HeaderUpload;