import {React, useEffect, useState} from 'react';
import './enviar.css';

/**
 * Componente que muestra el botón de enviar publicación a gente
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function Enviar(props) {
    const [personas, setPersonas] = useState([]);
    const [personasMostrar, setPersonasMostrar] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        getPersonas();
    }, []);

    /**
     * Filtra las personas que coinciden con el texto introducido
     * con el nombre de usuario de las personas que sigue
     * @param {Event} event 
     */
    function search(event) {
        let personasFiltradas = personas.filter(persona => persona.usuario.toLowerCase().includes(event.target.value.toLowerCase()));
        setPersonasMostrar(personasFiltradas);
    }

    /**
     * Obtiene las personas que sigue el usuario
     */
    function getPersonas() {
        fetch(props.url + '/api/getPersonasEtiquetar/' + props.user.id)
        .then((response) => response.json())
        .then((data) => {
            setPersonas(data);
            setIsLoading(false);
        })
        .catch((error) => console.error(error));
    }
    
    return (
        <>
            <div className='compartirPersonasDiv'>
                <div className='compartirPersonasSelectDiv'>
                    <div className="dropdown botomDropdownCompartirUpload">
                        <a className="btn dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            {props.selectedPersonas ? <div><img src={props.selectedPersonas.foto_perfil} className="imagenOptionEtiquetados"/>{props.selectedPersonas.usuario}</div> : 'Selecciona una persona'}
                        </a>

                        <ul className="dropdown-menu">
                            <li><input className='dropdown-item inputSearchEtiquetar' type='text' placeholder='Buscar...' onChange={search}/></li>
                            <li><a className="dropdown-item" onClick={() => {props.setSelectedPersonas(null)}}>No compartir con nadie</a></li>
                            {
                                isLoading ? <li key="loading"><a className="dropdown-item">Cargando...</a></li> : personasMostrar.map((persona, index) => {
                                    return <li key={index}><a className="dropdown-item divTextEtiquetados" onClick={
                                            () => {props.setSelectedPersonas(persona)}
                                        }>
                                            <img src={persona.foto_perfil} className="imagenOptionEtiquetados"/>
                                            {persona.usuario}
                                        </a></li>
                                })
                            }
                        </ul>
                    </div>
                    <div className='mensajeParaCompartirUploadDiv'>
                        {props.selectedPersonas ? <input type="text" name="descripcion" placeholder="Escribe tu mensaje" className='mensajeParaCompartirUpload' id="mensajeParaCompartirUpload"/> : <input type="text" name="descripcion" placeholder="Escribe tu mensaje" className='mensajeParaCompartirUpload' id="mensajeParaCompartirUpload" disabled/>}
                    </div>
                </div>
                <div className='compartirPersonasTextoDiv'>
                    <h5><b>Compartir personas:</b></h5>
                    <span>Ahora puedes compartir tu publicación. Solo puedes enviar a gente que sigues</span>
                </div>
            </div> 
        </>
    );
}
  
export default Enviar;