import { React, useEffect, useState } from 'react';
import { Link } from "react-router-dom";
import './footer.css';

/**
 * Componente footer
 * @param {Object} param0 
 * @returns {JSX.Element}
 */
function Footer({ user }) {

    return (
        <>
            <div className="bg-body-tertiary footer">
                <ul className="navbar-nav me-auto mb-lg-0 listaBotones">
                    <li className="nav-item">
                        <Link to="/" className="nav-link active" aria-current="page" ><img src="/assets/home.png" className="logo" /></Link>
                    </li>
                    <li className="nav-item">
                        <Link to="/ranking" className="nav-link"><img src="/assets/ranking.png" className="logo" /></Link>
                    </li>
                    <li className="nav-item">
                        <div className="dropup-center dropup">
                            <button className="btn dropdown-toggle botonPublicacion" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <img src="/assets/subirPeta.png" className="logo subir" />
                            </button>
                            <ul className="dropdown-menu">
                                <li>
                                    <Link to="/uploadPublicacion" className="dropdown-item">Publicacion</Link>
                                </li>
                                <li>
                                    <Link to="/spotify" className="dropdown-item">Spotify</Link>
                                </li>
                                {
                                    user && user.id === 1 && user.usuario === 'ByMarqueZz' ?
                                        <li>
                                            <Link to="/admin" className="dropdown-item">Admin</Link>
                                        </li>
                                        : ''
                                }

                            </ul>
                        </div>
                    </li>
                    <li className="nav-item">
                        <Link to="/historial" className="nav-link"><img src="/assets/historial.png" className="logo" /></Link>
                    </li>
                    <li className="nav-item">
                        
                            <Link to={"/perfil/"+user.id} className="nav-link"><img src={user.foto_perfil} className="logo logoPerfil" /></Link>
                        
                        
                    </li>
                </ul>
            </div>
        </>
    )


}

export default Footer;