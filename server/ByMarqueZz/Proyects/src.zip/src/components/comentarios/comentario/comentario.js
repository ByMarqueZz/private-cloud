import {React, useEffect, useState} from 'react';
import { Link } from "react-router-dom";
import './comentario.css';

/**
 * Componente comentario
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function Comentario(props) {
    const [segundaRuta, setSegundaRuta] = useState('');
    const [fecha, setFecha] = useState('');
    const [permisos, setPermisos] = useState(false);

    useEffect(() => {
        if (props.segundaRuta) {
            setSegundaRuta(props.segundaRuta);
        }
        setFecha(calcularTiempo(props.comentario.fecha));
        comprobarPermisosUsuario();
    }, []);

    /**
     * Devuelve el tiempo que ha pasado desde la fecha que le pases
     * @param {String} fecha 
     * @returns {String}
     */
    function calcularTiempo(fecha) {
        // función que calcula el tiempo que ha pasado desde la última publicación
        let fechaActual = new Date();
        let fechaPublicacion = new Date(fecha);
        let diferencia = fechaActual.getTime() - fechaPublicacion.getTime();
        // si la diferencia es menor a 1 minuto, se devuelve hace un momento si no, se devuelve hace x minutos o x horas o x días o x meses o x años
        if(diferencia < 60000) {
            return 'hace un momento';
        } else if(diferencia < 3600000) {
            return 'hace un momento';
        } else if(diferencia < 86400000) {
            return 'hace un momento';
        } else if(diferencia < 2592000000) {
            return 'hace ' + Math.floor(diferencia / 86400000) + ' días';
        } else if(diferencia < 31536000000) {
            return 'hace ' + Math.floor(diferencia / 2592000000) + ' meses';
        } else {
            return 'hace ' + Math.floor(diferencia / 31536000000) + ' años';
        }
    }

    /**
     * Comprueba si el usuario tiene permisos porque es el dueño de la publicacion o es el administrador
     */
    function comprobarPermisosUsuario() {
        // console.log( props.publicacion.usuario)
        if (props.usuario.usuario == props.comentario.usuario || props.usuario.usuario == 'ByMarqueZz') {
            setPermisos(true);
        } else {
            setPermisos(false);
        }
    }

    /**
     * Borra el comentario
     */
    function borrarComentario() {
        fetch(props.url+'/api/deleteComentario/' + props.comentario.id)
        .then((response) => response.json())
        .then((data) => {
            props.actualizarComentarios();
        })
    }

    return (
        <>
            {
                permisos ? <div className="modal fade" id="staticBackdrop2" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div className="modal-dialog">
                    <div className="modal-content">
                    <div className="modal-header">
                        <h1 className="modal-title fs-5" id="staticBackdropLabel">Eliminar foto</h1>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div className="modal-body">
                        ¿Desea borrar el comentario?
                        Está acción no se puede deshacer.
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">No</button>
                        <button type="button" className="btn btn-primary" data-bs-dismiss="modal" onClick={borrarComentario}>Sí</button>
                    </div>
                    </div>
                </div>
            </div> : ''
            }
           <div className='comentario'>
                <div className='comentarioHeader'>
                    <div className='comentarioHeaderImg'>
                        <Link to={"/perfil/"+props.comentario.id_usuario}><img src={props.comentario.foto_perfil} alt='imagen de perfil'/></Link>
                    </div>
                </div>
                <div className='comentarioBody'>
                    <div className='primeraParteComentario'>
                        <div className='comentarioHeaderNombre'>
                            {props.comentario.usuario}
                        </div>
                        <div>
                            {fecha}
                        </div>
                    </div>
                    {props.comentario.texto}
                </div>
                {permisos ? <div className='publicacion__header__eliminar'><button type="button" className='buttonBorrarPubli' data-bs-toggle="modal" data-bs-target="#staticBackdrop2"><img src={'/assets/tres-puntos.png'} className='iconoBasura'/></button></div> : ''}
           </div>
        </>
    );
}
  
export default Comentario;