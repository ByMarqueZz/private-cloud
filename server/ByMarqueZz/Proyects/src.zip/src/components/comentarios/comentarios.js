import {React, useEffect, useState} from 'react';
import './comentarios.css';
import Comentario from './comentario/comentario';

/**
 * Componente que muestra los comentarios de la publicacion
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function Comentarios(props) {
    const [comentarios, setComentarios] = useState([]);
    const [parametro] = useState(window.location.href.split('/')[4]);
    const [comentario, setComentario] = useState('');

    useEffect(() => {
        getComentarios();
    }, []);

    /**
     * Obtiene los comentarios de la publicacion
     */
    function getComentarios() {
        fetch(props.url+'/api/comentarios/'+parametro)
        .then(res => res.json())
        .then(data => {
            setComentarios(data);
        });
    }

    /**
     * Añade un comentario a la publicacion
     */
    function addComentario() {
        fetch(props.url+'/api/addComentario/'+parametro+'/'+props.user.id+'/'+comentario)
        .then(res => res.json())
        .then(data => {
            getComentarios();
        });
    }

    /**
     * Coge el valor del input de comentarios y lo guarda en el estado
     * @param {String} e 
     */
    function setValueComentario(e) {
        setComentario(e.target.value);
    }

    return (
        <>
            <div className='inputEscribirComentario'>
                <input type='text' placeholder='Escribe un comentario...' onChange={setValueComentario}/>
                <button className='btn btn-outline-success' onClick={addComentario}>Publicar</button>
            </div>
            <div className='comentariosDiv'>
                {
                    comentarios.length > 0 ? comentarios.map(
                        (comentario, index) => {
                            return <Comentario url={props.url} actualizarComentarios={getComentarios} key={index} comentario={comentario} segundaRuta={'.'} usuario={props.user}/>
                        }
                    ): 'No hay comentarios en esta publicacion'
                }
            </div>
        </>
    );
}
  
export default Comentarios;