import {React, useEffect, useState} from 'react';
import './historial.css';
import PublicacionHistorial from './publicacionHistorial/publicacionHistorial';

/**
 * Componente historial
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function Historial(props) {
    const [listaHistorial, setListaHistorial] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        peticionHistorial();
        setMainBackground();
    }, []);

    /**
     * Peticion para obtener el historial del usuario
     */
    function peticionHistorial() {
        fetch(props.url+'/api/historial/' + props.user.id)
        .then(res => res.json())
        .then(data => {
            setListaHistorial(data);
            setIsLoading(false);
        })
    }

    /**
     * Cambia el color de fondo de la pagina
     */
    function setMainBackground() {
        document.getElementsByClassName('main')[0].style.background = 'white';
      }

    /**
     * Efecto de cargando hasta que se nos devuelva la lista de historial
     */
    if(isLoading) return (
        <>
            <div className='historial'>
                <h1>Historial</h1>
                <div className='divListaHistorial'>
                    
                    <div className='elementoHistorial'>
                        <div className='elementoHistorial__child'>
                            <div className='elementoHistorial__numero cargando'>Cargando...</div>
                            <div className='elementoHistorial__fecha cargando'>Cargando...</div>
                        </div>
                        <div className='elementoHistorial__child'>
                            <div className='elementoHistorial__foto_div cargando'></div>
                        </div>
                    </div>
                    <div className='elementoHistorial'>
                        <div className='elementoHistorial__child'>
                            <div className='elementoHistorial__numero cargando'>Cargando...</div>
                            <div className='elementoHistorial__fecha cargando'>Cargando...</div>
                        </div>
                        <div className='elementoHistorial__child'>
                            <div className='elementoHistorial__foto_div cargando'></div>
                        </div>
                    </div>
                    <div className='elementoHistorial'>
                        <div className='elementoHistorial__child'>
                            <div className='elementoHistorial__numero cargando'>Cargando...</div>
                            <div className='elementoHistorial__fecha cargando'>Cargando...</div>
                        </div>
                        <div className='elementoHistorial__child'>
                            <div className='elementoHistorial__foto_div cargando'></div>
                        </div>
                    </div>
                    
                </div>
            </div>  
        </>
    );

    return (
        <>
            <div className='historial'>
                <h1>Historial</h1>
                <div className='divListaHistorial'>
                    {
                        listaHistorial.map((historial, index) => {
                            return (
                                <PublicacionHistorial data={historial} key={index} indice={index}/>
                            )
                        })
                    }
                </div>
            </div>
        </>
    );
}
  
export default Historial;