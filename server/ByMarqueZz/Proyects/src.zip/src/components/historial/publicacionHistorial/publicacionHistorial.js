import {React, useEffect, useState} from 'react';
import './publicacionHistorial.css';
import { Link } from "react-router-dom";

/**
 * Componente publicacionHistorial
 * @param {Object} param0 
 * @returns {JSX.Element}
 */
function PublicacionHistorial({data, indice}) {
    if (data.firestore != null) {
        return (
            <>
                <div className='elementoHistorial'>
                    <div className='elementoHistorial__child'>
                        <div className='elementoHistorial__numero'>{indice+1}</div>
                        <div className='elementoHistorial__fecha'>Foto del {data.fecha.split('T')[0]}</div>
                    </div>
                    <Link to={"/publicacion/"+data.id_publicacion}>
                        <div className='elementoHistorial__child'>
                            <div className='elementoHistorial__foto_div'><img src={data.foto} className='elementoHistorial__foto'/></div>
                        </div>
                    </Link>
                </div>
            </>
        );
    }
    return (
        <>
            <div className='elementoHistorial'>
                <div className='elementoHistorial__child'>
                    <div className='elementoHistorial__numero'>{indice+1}</div>
                    <div className='elementoHistorial__fecha'>Foto del {data.fecha.split('T')[0]}</div>
                </div>
                <Link to={"/publicacion/"+data.id_publicacion}>
                    <div className='elementoHistorial__child'>
                        <div className='elementoHistorial__foto_div'><img src={'/uploaded/'+data.usuario+'/publicaciones/'+data.foto} className='elementoHistorial__foto'/></div>
                    </div>
                </Link>
            </div>
        </>
    );
}
  
export default PublicacionHistorial;