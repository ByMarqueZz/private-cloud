import {React, useEffect, useState} from 'react';
import './novedades.css';

/**
 * 
 * @returns {JSX.Element}
 */
function Novedades() {

    useEffect(() => {
        setMainBackground();
    }, []);

    /**
     * Devuelve cuanto tiempo ha pasado desde la publicacion
     * @param {String} fecha 
     * @returns {String}
     */
    function calcularTiempo(fecha) {
        let fechaActual = new Date();
        let fechaPublicacion = new Date(fecha);
        let diferencia = fechaActual.getTime() - fechaPublicacion.getTime();
        // si la diferencia es menor a 1 día, se devuelve hace un momento si no, se devuelve hace x días o x meses o x años
        if (diferencia < 86400000) {
            return 'Hace un momento';
        }
        else if (diferencia < 2592000000) {
            return 'Hace ' + Math.round(diferencia / 86400000) + ' días';
        }
        else if (diferencia < 31104000000) {
            return 'Hace ' + Math.round(diferencia / 2592000000) + ' meses';
        }
        else {
            return 'Hace ' + Math.round(diferencia / 31104000000) + ' años';
        }
        
    }

    /**
     * Cambia el color de fondo de la pagina
     */
    function setMainBackground() {
        document.getElementsByClassName('main')[0].style.background = 'white';
      }

    return (
        <>
            <div className='listaNovedades'>

                <div className="card text-center">
                    <div className="card-header">
                        <div className='imagenCardHeaderDiv'><img src='./uploaded/ByMarqueZz/perfil/foto_perfil.jpg' className='imagenCardHeader'/></div>
                        Admin
                    </div>
                    <div className="card-body">
                        <h2 className="card-title">Concurso de bienvenida</h2>
                        <p className="card-text colorYellow">
                            <b>01-04-2023 / 15-04-2023</b>
                        </p>
                        <p className="card-text">
                            Premio: 
                        </p>
                        <div className='imgConcursoDiv'>
                            <img src="./assets/concurso2.jpg" className='imgConcurso' />
                        </div>
                        
                        <details>
                            <summary>Leer Más</summary>
                            <p className="card-text">El premio consistirá en un surtido de papeles aleatorios valorados entre 3-5€ aproximadamente. En los que incluiré papeles de L, normales, sabores, conos, etc...</p>
                            <p className="card-text colorRed">LA IMAGEN DEL CONCURSO NO TIENE NADA QUE VER CON EL PRODUCTO FINAL ES SOLO ORIENTATIVA</p>
                            <p className="card-text">El segundo concurso existente en la página que durará 15 días</p>
                            <p className="card-text">El concurso del más porrero consiste en que los usuarios de la página suban sus mejores fotos de petas y las compartan con el resto de usuarios. El usuario que tenga la mayor cantidad de petas fumados ganará el concurso. La cantidad de petardos será verificada con la foto, la fecha y hora de la publicación. No serán validos aquellos petas que sean repetidos o falsificados, es una competición real y honesta. Sin nada más que decir, mucha suerte gente y a fumar mucho.</p>
                        </details>
                        
                    </div>
                    <div className="card-footer text-muted">
                        {calcularTiempo('2023-02-21T00:00:00.000Z')}
                    </div>
                </div>

                <div className="card text-center">
                    <div className="card-header">
                        <div className='imagenCardHeaderDiv'><img src='./uploaded/ByMarqueZz/perfil/foto_perfil.jpg' className='imagenCardHeader'/></div>
                        Admin
                    </div>
                    <div className="card-body">
                        <h2 className="card-title">Joints Counter v3</h2>
                        <p className="card-text">
                            Estamos en pleno desarrollo de la versión 3 de Joints Counter, un escalón hacia la sostenibilidad y prolongación de la aplicación.
                        </p>
                        <details>
                            <summary>Leer Más</summary>
                            <p className="card-text">
                                En esta nueva versión de la página optamos por nuevas tecnologías de desarrollo web, como React y NodeJs que nos permite pasar de una aplicación estática a una aplicación dinámica, con una base de datos y un servidor que nos permite almacenar y gestionar los datos de los usuarios y las publicaciones sin la necesidad de recargar la página.
                            </p>
                            <p className="card-text">
                                Tenemos en mente ideas como sacar historias, añadir un sistema de notificaciones o crear una aplicación móvil para que no te de flojera subir tus publicaciones.
                            </p>
                            <p className="card-text">
                                Si tienes alguna idea o sugerencia, no dudes en contactar con nosotros en <a href='mailto:jointscounter@gmail.com' target='_blank'>jointscounter@gmail.com</a>
                            </p>
                        </details>
                        
                    </div>
                    <div className="card-footer text-muted">
                        {calcularTiempo('2023-02-21T00:00:00.000Z')}
                    </div>
                </div>

                
                
            </div>
            
        </>
    );
}
  
export default Novedades;