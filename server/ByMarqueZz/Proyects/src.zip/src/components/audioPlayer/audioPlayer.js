import React, { useState } from "react";
import "./audioPlayer.css";

const AudioPlayer = (props) => {
    const [isPlaying, setIsPlaying] = useState(false);
    const [isSelected, setIsSelected] = useState(false);

    const togglePlay = () => {
        const audio = document.getElementById("audio"+props.i);
        if (isPlaying) {
            audio.pause();
            setIsPlaying(false);
        } else {
            audio.play();
            setIsPlaying(true);
        }
    };

    return (
        <div className="audio-player">
            <div className="first-child-audio-player">
                <div className="audio-select">
                    <button onClick={() => {
                        setIsSelected(!isSelected);
                        if(isSelected == false) {
                            props.addSong(props.id);
                        } else {
                            props.addSong(null);
                        }
                    }}>
                        <div className="playButton" style={{ width: "20px" }}>
                            {
                                isSelected ? <img className='btn-pause' src="/assets/tick.png"></img> :
                                <img className='btn-pause' src="/assets/plus.png"></img>
                            }
                        </div>
                    </button>
                </div>

                <div className="audio-player-div">
                    <audio id={"audio"+props.i} src={props.src}></audio>
                    <button onClick={togglePlay}>
                        <div className="playButton" style={{ width: "30px" }}>
                            {isPlaying ? (
                                <img className='btn-pause' src="/assets/pause.png"></img>
                            ) : (
                                <img className='btn-pause' src="/assets/play.png"></img>
                            )}
                        </div>
                    </button>
                </div>
            </div>

            <div className="first-child-audio-player">
                <div className="div-image-audio-player">
                    <img src={props.imageSrc}></img>
                </div>
                <div>
                    <span>{props.tittle}</span>
                </div>
            </div>
            
            
            
            

            

        </div>
    );
};

export default AudioPlayer;
