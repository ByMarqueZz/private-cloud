import {React, useEffect, useState} from 'react';
import './publicacion.css';
import Comentario from '../../comentarios/comentario/comentario';
import { Link } from "react-router-dom";
import { Router, Navigate, useNavigate } from 'react-router-dom';

/**
 * Componente publicacion
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function Publicacion(props) {
    const [haDadoLike, setHaDadoLike] = useState(false);
    const [touchTime, setTouchTime] = useState(0);
    const [permisos, setPermisos] = useState(false);
    const [fecha, setFecha] = useState('');
    const [comentarios, setComentarios] = useState([]);
    const [segundaRuta, setSegundaRuta] = useState('');
    const [ruta, setRuta] = useState('');
    const [cantidadLikes, setCantidadLikes] = useState(props.publicacion.cantidad_likes)
    const navigate = useNavigate();

    useEffect(() => {
        if (props.segundaRuta) {
            setSegundaRuta(props.segundaRuta);
        }
        if(props.publicacion.firestore != null) {
            setRuta(props.publicacion.foto);
        } else {
            setRuta('/uploaded/'+props.nombre+'/publicaciones/'+props.imagen);
        }
        comprobarLike();
        comprobarPermisosUsuario();
        setFecha(calcularTiempo(props.publicacion.fecha));
        getComentarios();
    }, []);

    /**
     * Obtiene los comentarios de la publicacion del servidor
     */
    function getComentarios() {
        fetch(props.url+'/api/comentarios/'+props.publicacion.id_publicacion)
        .then(res => res.json())
        .then(data => {
            if(data.length > 3) {
                setComentarios(data.slice(0, 3));
            } else {
                setComentarios(data);
            }
        });
    }

    /**
     * Añade un like a la publicacion
     */
    function handleTouchStart() {
        // detecta si se ha hecho doble click en movil
        if (touchTime === 0) {
            setTouchTime(Date.now());
        } else {
            if (Date.now() - touchTime < 500) {
            likear();
            }
            setTouchTime(0);
        }
    }

    function handleTouchStartUnLike() {
        // detecta si se ha hecho doble click en movil
        if (touchTime === 0) {
            setTouchTime(Date.now());
        } else {
            if (Date.now() - touchTime < 500) {
                unlike();
            }
            setTouchTime(0);
        }
    }

    /**
     * Devuelve cuanto tiempo ha pasado desde la publicacion
     * @param {String} fecha 
     * @returns {String}
     */
    function calcularTiempo(fecha) {
        let fechaActual = new Date();
        let fechaPublicacion = new Date(fecha);
        let diferencia = fechaActual.getTime() - fechaPublicacion.getTime();
        // si la diferencia es menor a 1 minuto, se devuelve hace un momento si no, se devuelve hace x minutos o x horas o x días o x meses o x años
        if(diferencia < 60000) {
            return 'hace un momento';
        } else if(diferencia < 3600000) {
            return 'hace un momento';
        } else if(diferencia < 86400000) {
            return 'hace un momento';
        } else if(diferencia < 2592000000) {
            return 'hace ' + Math.floor(diferencia / 86400000) + ' días';
        } else if(diferencia < 31536000000) {
            return 'hace ' + Math.floor(diferencia / 2592000000) + ' meses';
        } else {
            return 'hace ' + Math.floor(diferencia / 31536000000) + ' años';
        }
    }
    
    /**
     * Comprueba si el usuario tiene permisos para borrar la publicacion
     */
    function comprobarPermisosUsuario() {
        // console.log( props.publicacion.usuario)
        if (props.usuario.usuario == props.publicacion.usuario || props.usuario.usuario == 'ByMarqueZz') {
            setPermisos(true);
        } else {
            setPermisos(false);
        }
    }
    
    /**
     * Comprueba si el usuario ha dado like a la publicacion para poner una foto u otra
     */
    function comprobarLike() {
        if(props.like === 1) {
            setHaDadoLike(true);
        } else {
            setHaDadoLike(false);
        }
    }

    /**
     * Guarda el like en la base de datos
     */
    function likear() {
        fetch(props.url+'/api/like/'+props.publicacion.id_publicacion+'/'+props.usuario.id)
        .then(res => res.json())
        .then(data => {
            if (data) {
                setHaDadoLike(true);
                let number = document.getElementsByClassName('cantidad_exacta_likes_publicacion')[0];
                if(number > 0) {
                    let parsetNumber = parseInt(number);
                    setCantidadLikes(parsetNumber + 1);
                } else {
                    setCantidadLikes(1);
                }
                let img = document.getElementById('like'+props.publicacion.id_publicacion);
                img.classList.add("fade-out");
                setTimeout(function() {
                    img.classList.remove("fade-out");
                    }, 300);
            }
        });
    }

    function unlike() {
        fetch(props.url+'/api/unlike/'+props.publicacion.id_publicacion+'/'+props.usuario.id)
        .then(res => res.json())
        .then(data => {
            if (data) {
                setHaDadoLike(false);
                let number = document.getElementsByClassName('cantidad_exacta_likes_publicacion')[0];
                if(number == 1) {
                    setCantidadLikes(0);
                } else {
                    let parsetNumber = parseInt(number);
                    setCantidadLikes(parsetNumber - 1);
                }
                let img = document.getElementById('like'+props.publicacion.id_publicacion);
                img.classList.add("fade-out");
                setTimeout(function() {
                    img.classList.remove("fade-out");
                    }, 300);
            }
        });
    }

    /**
     * Borra la publicacion
     */
    function borrarFoto() {
        fetch(props.url+'/api/delete/'+props.publicacion.id_publicacion)
        .then(res => res.json())
        .then(data => {
            if(data === 'borrado') {
                window.location.href = 'https://www.jointscounter.com'
            }
        });
    }

    return (
        <>
            {
                permisos ? <div className="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div className="modal-dialog">
                    <div className="modal-content">
                    <div className="modal-header">
                        <h1 className="modal-title fs-5" id="staticBackdropLabel">Eliminar foto</h1>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div className="modal-body">
                        ¿Desea borrar la foto?
                        Está acción no se puede deshacer.
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">No</button>
                        <button type="button" className="btn btn-primary" onClick={borrarFoto}>Sí</button>
                    </div>
                    </div>
                </div>
            </div> : ''
            }
            <div className='publicacion'>
                <div className='publicacion__header'>
                    <div className='publicacion__header__foto publicacion__header__nombre'><Link to={"/perfil/"+props.publicacion.id}><img src={props.foto_perfil}/></Link>{props.nombre}</div>
                    {permisos ? <div className='publicacion__header__eliminar'><button type="button" className='buttonBorrarPubli' data-bs-toggle="modal" data-bs-target="#staticBackdrop"><img src={segundaRuta+'./assets/tres-puntos.png'} className='iconoBasura'/></button></div> : ''}
                </div>
                {
                    props.publicacion.id_usuario_etiquetado ? 
                        <div className='publicacion__etiquetado'>
                            <div className='publicacion__etiquetado__fecha'>Fumado a medias con:</div>
                            <div className='publicacion__etiquetado__foto'><Link to={"/perfil/"+props.publicacion.id_usuario_etiquetado}><img src={props.publicacion.foto_usuario_etiquetado}/></Link></div>
                            <div className='publicacion__etiquetado__nombre'>{props.publicacion.nombre_usuario_etiquetado}</div>
                        </div> : ''
                }
                {
                    haDadoLike ? <div className='publicacion__contenido' onTouchStart={handleTouchStartUnLike} onDoubleClick={unlike}>
                    <img src={ruta} className='imagenPublicacionContenido'/>
                </div> : <div className='publicacion__contenido' onTouchStart={handleTouchStart} onDoubleClick={likear}>
                    <img src={ruta} className='imagenPublicacionContenido'/>
                </div>
                }
                
                <div className='publicacion_comentarios'>
                    <div className='publicacion__footer'>
                        <div className='publicacion__footer__like'>
                            {
                                haDadoLike ? <img id={'like'+props.publicacion.id_publicacion} src='/assets/like2.png' className='botonFooter like' onClick={unlike}/> : <img id={'like'+props.publicacion.id_publicacion} src='/assets/like.png' className='botonFooter like' onClick={likear}/>
                            }
                            
                        </div>
                        <div className='publicacion__footer__comentario'>
                            <Link to={'/comentarios/'+props.publicacion.id_publicacion}><img src={'/assets/comentario.png'} className='botonFooter'/></Link>
                        </div>
                        <div className='publicacion__footer__compartir'>
                            <img src={'/assets/share.png'} className='botonFooter'/>
                        </div>
                    </div>
                    <div className='count_likes'>
                        <p className='cantidad_like_publicacion'>
                            {
                                cantidadLikes > 0 ? cantidadLikes == 1 ? <b><span className='cantidad_exacta_likes_publicacion'>1</span> me gusta</b>  : <b><span className='cantidad_exacta_likes_publicacion'>{cantidadLikes}</span> me gustas</b> : <b><span className='cantidad_exacta_likes_publicacion'>0</span> me gustas</b> 
                            }
                        </p>
                    </div>
                    <div className='descripcion_publicacion'>
                        <p><b>{props.nombre}</b> {
                        props.publicacion.descripcion ? <span> {' '+props.publicacion.descripcion}</span>: ''
                        }</p>
                        
                    </div>
                
                    
                    {
                        comentarios.length > 0 ? <div className='comentarios-div-publicacion'>
                            <Link className="ver-x-comentarios-mas" to={'/comentarios/'+props.publicacion.id_publicacion}>Ver {comentarios.length == 1 ? 'el comentario':comentarios.length+' comentarios'}</Link>
                            {
                                comentarios.map(
                                    (comentario, index) => {
                                        return <Comentario actualizarComentarios={getComentarios} url={props.url} key={index} comentario={comentario} segundaRuta={'.'} usuario={props.usuario}/>
                                    }
                                )
                            }
                        </div>: 'No hay comentarios en esta publicacion'
                    }
                    {
                        <div className='publicacion__header__fecha'>
                            {fecha}
                        </div>
                        
                    }
                </div>
            </div>
        </>
    );
}
  
export default Publicacion;