import {React, useEffect, useState, Navigate} from 'react';
import './home.css';
import Publicacion from './publicacion/publicacion';

/**
 * Componente home, se encarga de mostrar las publicaciones de los usuarios nada más iniciar sesión	
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function Home(props) {

    const [publicaciones, setPublicaciones] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [numPublicaciones, setNumPublicaciones] = useState(0);
    const [numPagina, setNumPagina] = useState(0);
    const [vecesCargadas, setVecesCargadas] = useState(0);
    const [coolDown, setCoolDown] = useState(false);

    useEffect(() => {
        getPublicaciones();
        setMainBackground();
    }, []);

    /**
     * Peticion para obtener las publicaciones según el usuario que inicia sesión
     */
    function getPublicaciones() {
        fetch(props.url+'/api/publicaciones/'+props.user.id)
        .then(res => res.json())
        .then(data => {
            data.forEach(publicacion => {
                if (publicacion.comentarios) {
                    publicacion.comentarios = JSON.parse(publicacion.comentarios);
                }
            });
            setPublicaciones(data.slice(0, numPagina + 10));
            setIsLoading(false);
            setNumPublicaciones(data.length);
        });
    }

    /**
     * Encargado de pedir más publicaciones al servidor
     */
    function pushFotos() {
        fetch(props.url+'/api/publicaciones/'+props.user.id)
        .then(res => res.json())
        .then(data => {
            let num = comprobarScroll();
            setPublicaciones(data.slice(0, numPagina + num));
            setCoolDown(false);
        });
    }

    /**
     * Comprueba si se puede cargar 10 más
     * En caso de que no se pueda, se calcula el número de publicaciones que se pueden cargar
     * @returns {Number} Devuelve el número de veces que se pueden cargar
     */
    function comprobarScroll() {
        let vecesQuePuedeRepetirse = Math.floor(numPublicaciones / 10);
        if (vecesCargadas < vecesQuePuedeRepetirse) {
            return 10;
        } else {
            return numPublicaciones - (vecesCargadas * 10);
        }
    }

    /**
     * Carga más publicaciones
     */
    function cargarMas() {
        setCoolDown(true);
        setNumPagina(numPagina + 10);
        setVecesCargadas(vecesCargadas + 1);
        pushFotos();
    }

    /**
     * Cambia el color de fondo de la página
     */
    function setMainBackground() {
        document.getElementsByClassName('main')[0].style.background = 'white';
    }

    // function activarNotificaciones() {
    //     Notification.requestPermission().then(function(result) {
    //         if (result === 'granted') {
    //             props.setAllowNotifications(true);
    //         }
    //     });
    // }
    // function notificacionPrueba() {
    //     if ("Notification" in window) {
    //       // Comprobar si el usuario ya concedió permiso para las notificaciones
    //       if (Notification.permission === "granted") {
    //         const notificacion = new Notification("Joints Counter", {
    //           body: "Joints Counter te está esperando para fumarte un buen porro",
    //           icon: "./assets/logo.png"
    //         });
    //         notificacion.onclick = () => {
    //           window.open("http://161.35.28.163:3080");
    //         };
    //       }
    //     }
    //   }
    
    /**
     * Efecto hasta que nos lleguen las publicaciones
     */
    if(isLoading) return (
        <>
            <div className='publicacion'>
                <div className='publicacion__header'>
                    <div className='publicacion__header__foto cargando'></div>
                    <div className='publicacion__header__nombre cargando'>Cargando...</div>
                </div>
                <div className='publicacion__contenido cargando'>
                    <img src='./assets/fotoCargando.jpg'/>
                </div>
                <div className='publicacion__footer cargando'>
                    <div className='publicacion__footer__like'>
                       
                    </div>
                    <div className='publicacion__footer__comentario'>
                        
                    </div>
                    <div className='publicacion__footer__compartir'>
                        
                    </div>
                </div>
            </div>
            <div className='publicacion'>
                <div className='publicacion__header'>
                    <div className='publicacion__header__foto cargando'></div>
                    <div className='publicacion__header__nombre cargando'>Cargando...</div>
                </div>
                <div className='publicacion__contenido cargando'>
                    <img src='./assets/fotoCargando.jpg'/>
                </div>
                <div className='publicacion__footer cargando'>
                    <div className='publicacion__footer__like'>
                       
                    </div>
                    <div className='publicacion__footer__comentario'>
                        
                    </div>
                    <div className='publicacion__footer__compartir'>
                        
                    </div>
                </div>
            </div>
            
        </>
    );

    return (
        <>
            {/* {
                !props.allowNotifications ? <div className="toast-container">
                <div className="toast show" id="myToast">
                  <div className="toast-header">
                    <strong className="mr-auto">Activar notificaciones</strong>
                    <button type="button" className="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close" onClick={() => {
                        let toast = document.getElementById('myToast');
                        toast.style.display = 'none';
                    }}>&times;</button>
                  </div>
                  <div className="toast-body">
                    Haz clic en el botón para activar las notificaciones.
                    <button className='btn btn-outline-success' onClick={activarNotificaciones}>Activar</button>
                  </div>
                </div>
              </div> : ''
            } */}
            {publicaciones.map((publicacion, index) => {
                return <Publicacion url={props.url} like={publicacion.ha_dado_like} publicacion={publicacion} usuario={props.user} id={publicacion.id} foto_perfil={publicacion.foto_perfil} nombre={publicacion.usuario} imagen={publicacion.foto} fecha={publicacion.fecha} id_usuario_publicacion={publicacion.id} key={index}/>
            })}
            {coolDown ? <button className='btn btn-outline-success' onClick={cargarMas}>Cargando...</button> : <button className='btn btn-outline-success' onClick={cargarMas}>Cargar más</button>}
        </>
    );
}
  
export default Home;