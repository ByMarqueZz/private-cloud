import {React, useEffect, useState} from 'react';
import { Link } from "react-router-dom";
import './header.css';

/**
 * Componente header
 * @returns {JSX.Element}
 */
function Header() {

    return (
        <>
            <div className="header">
                <div className="titulo">
                    <Link to="/" className="nav-link active"><span className="titulo">Joints Counter</span></Link>
                </div>
                <div className="botones">
                    <ul className="listaBotonesHeader">
                        <li>
                            <Link to="/novedades" className="nav-link active" aria-current="page" ><img src="/assets/novedades.png" className="logo"/></Link>
                        </li>
                        <li>
                            <Link to="/mensajes" className="nav-link active" aria-current="page" ><img src="/assets/mensajes.png" className="logo"/></Link>
                        </li>
                    </ul>
                </div>
            </div>
            <hr/>
        </>
    );
}
  
export default Header;