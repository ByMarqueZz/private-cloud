import {React, useEffect, useState} from 'react';
import './ranking.css';
import {Link} from 'react-router-dom';

/**
 * Componente ranking muestra el ranking de usuarios
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function Ranking(props) {
    const [listaRanking, setListaRanking] = useState([]);
    const [totalFilas, setTotalFilas] = useState(0);
    const [isLoading, setIsLoading] = useState(true);
    const [isConcurso, setIsConcurso] = useState(false);

    useEffect(() => {
        if(props.urlPeticion.includes('/api/concursoActual')) {
            setIsConcurso(true);
            setMainBackground();
        }
        peticion();
    }, []);

    /**
     * Pide al servidor el ranking de usuarios
     */
    function peticion() {
        fetch(props.urlPeticion)
        .then(res => res.json())
        .then(data => {
            if (data.length > 0) {
                setListaRanking(data);
                setTotalFilas(data[0].total_filas);
            } else {
                setListaRanking([]);
                setTotalFilas(0);
            }
            setIsLoading(false);
        })
    }

    /**
     * Cambia el color de fondo de la página
     */
    function setMainBackground() {
        document.getElementsByClassName('main')[0].style.background = 'linear-gradient(to bottom, #FFAFBD, #ffc3a0)';
    }

    /**
     * Función que calcula el tiempo que queda para que finalice el concurso
     * @param {String} fecha 
     * @returns {String}
     */
    function calcularTiempoRestante(fecha) {
        let fechaActual = new Date();
        let fechaFin = new Date(fecha);
        let diferencia = fechaFin.getTime() - fechaActual.getTime();
        if(diferencia < 0) {
            return 'El concurso ha finalizado';
        } else {
            return 'El concurso finaliza en ' + Math.floor(diferencia / 86400000) + ' días, ' + Math.floor((diferencia % 86400000) / 3600000) + ' horas, ' + Math.floor((diferencia % 3600000) / 60000) + ' minutos y ' + Math.floor((diferencia % 60000) / 1000) + ' segundos';
        }
    }

    /**
     * Devuelve el tiempo que ha pasado desde la última publicación
     * @param {String} fecha 
     * @returns {String}
     */
    function calcularTiempo(fecha) {
        // función que calcula el tiempo que ha pasado desde la última publicación
        let fechaActual = new Date();
        let fechaPublicacion = new Date(fecha);
        let diferencia = fechaActual.getTime() - fechaPublicacion.getTime();
        // si la diferencia es menor a 1 minuto, se devuelve hace un momento si no, se devuelve hace x minutos o x horas o x días o x meses o x años
        if(diferencia < 60000) {
            return 'hace un momento';
        } else if(diferencia < 3600000) {
            return 'hace un momento';
        } else if(diferencia < 86400000) {
            return 'hace un momento';
        } else if(diferencia < 2592000000) {
            return 'hace ' + Math.floor(diferencia / 86400000) + ' días';
        } else if(diferencia < 31536000000) {
            return 'hace ' + Math.floor(diferencia / 2592000000) + ' meses';
        } else {
            return 'hace ' + Math.floor(diferencia / 31536000000) + ' años';
        }
    }

    /**
     * Efecto de carga
     */
    if(isLoading) return (
        <>
            <div className='ranking'>
                <h1 className='cargando'>Ranking</h1>
                <div className="podio cargando">
                </div>
                <div>
                    <p className='cargando'>Hay un total de </p>
                    <p className='totalFilas cargando'>Cargando...</p>
                    <p className='cargando'>petardos fumados</p>
                </div>
                <div className="lista">
                    {
                            <div className='usuarioRanking cargando'>
                                0 - 
                                <div className='divFotoPerfil'></div>
                                Cargando...
                                <b className='totalPuntuacion cargando'>Cargando...</b>
                                <p className='ultimoHace cargando'>Cargando...</p>
                            </div>
                    }
                </div>
            </div>
        </>
    )

    return (
        <>
            <div className='ranking'>
                {isConcurso ? <h1 className='rankingh1Concurso'>Ranking Concurso</h1> : <h1>Ranking</h1>}
                {isConcurso ? <p className='tiempoRestanteConcurso'>{calcularTiempoRestante(props.fechaFinal)}</p> : null}
                <div className="podio">
                    <img src="/assets/podio.png"/>
                </div>
                <div>
                    <p><b>Hay un total de </b></p>
                    <p className='totalFilas'>{totalFilas}</p>
                    <p><b>petardos fumados</b></p>
                </div>
                <div className="lista">
                    {
                        listaRanking.map((usuario, index) => {
                            return <div className='usuarioRanking' key={index}>
                                {index + 1}- 
                                <Link to={"/perfil/"+usuario.id_usuario}>
                                    <div className='divFotoPerfil'><img src={usuario.imagenPerfil} className='imagenPerfilRanking'/></div>
                                </Link>
                                <span className='usuarioNombreRanking'>{usuario.nombre}</span>
                                <b className='totalPuntuacion'>{usuario.puntuacion}</b>
                                <img src='/assets/reloj.png' className='reloj'/>
                                <p className='ultimoHace'>{calcularTiempo(usuario.fecha_ultima_publicacion)}</p>
                            </div>
                        })
                    }
                </div>
            </div>
        </>
    );
}
  
export default Ranking;