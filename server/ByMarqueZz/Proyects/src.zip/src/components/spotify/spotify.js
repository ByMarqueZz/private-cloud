import { React, useEffect, useState } from 'react';
import './spotify.css'
import AudioPlayer from '../audioPlayer/audioPlayer';

function Spotify(props) {
    const [isLoading, setIsLoading] = useState(true);
    const [tracks, setTracks] = useState(null);
    const [search, setSearch] = useState(props.search);

    useEffect(() => {
        getMusic();
    }, [search]);

    function getMusic() {
        if (search === '' || search.length < 2) return setIsLoading(false);
        fetch('https://api.spotify.com/v1/search?q=' + search + '&type=track&limit=15', {
            method: 'GET',
            headers: {
                'Authorization': 'Bearer ' + props.token
            }
        })
            .then((response) => response.json())
            .then((data) => {
                setTracks(data.tracks.items);
                setIsLoading(false);
            })
    }

    if (isLoading) return (<div>Loading...</div>)

    if (tracks.length === 0) return (<>
        <div className='div-search'>
            <input className='input-search' type='text' placeholder='Search' onChange={(e) => setSearch(e.target.value)}></input>
        </div>
        <div>No results</div>
    </>

    )

    return (
        <>
            <h5 className='h5-name-spoti'><b>Añade una canción: </b></h5>
            <div className='div-main-spotify-uploaded'>
                <div className='div-search'>
                    <input className='input-search' type='text' placeholder='Search' onChange={(e) => setSearch(e.target.value)}></input>
                </div>
                <div className={props.isUploading ? 'card-spotify limited-spotify-upload' : 'card-spotify'}>
                    {
                        tracks.map((item, index) => {
                            if(item.album.images.length === 0) return <AudioPlayer i={index} id={item.id} addSong={(id) => {props.setSelectedSong(id)}} key={index} src={item.preview_url} imageSrc='/assets/profile.png' tittle={item.name}></AudioPlayer>;
                            return <AudioPlayer i={index} id={item.id} addSong={(id) => {props.setSelectedSong(id)}} key={index} src={item.preview_url} imageSrc={item.album.images[0].url} tittle={item.name}></AudioPlayer>
                        })
                    }
                </div>
            </div>
        </>
    )
}

export default Spotify;