import {React, useEffect, useState} from 'react';
import Publicacion from '../home/publicacion/publicacion';
import {Navigate} from 'react-router-dom';

/**
 * Componente de publicacion sola
 * @param {Object} props 
 * @returns {JSX.Element}
 */
function PublicacionSola(props) {
    const [isLoading, setIsLoading] = useState(true);
    const [publicacion, setPublicacion] = useState([]);
    const [parametro, setParametro] = useState(window.location.href.split('/')[4]);

    function getPublicaciones() {
        if(parametro == '') {
            return;
        }
        fetch(props.url+'/api/publicacion/'+props.user.id+'/'+parametro)
        .then(res => res.json())
        .then(data => {
            setPublicacion(data[0]);
            setIsLoading(false);
        });
    }

    function getParam() {
        
        setParametro(parametro[4]);
    }

    function setMainBackground() {
        document.getElementsByClassName('main')[0].style.background = 'white';
      }

    useEffect(() => {
        setMainBackground();
        getPublicaciones();
    }, []);


    if (isLoading) {
        return(
            <>
                <div className='publicacion'>
                    <div className='publicacion__header'>
                        <div className='publicacion__header__foto cargando'></div>
                        <div className='publicacion__header__nombre cargando'>Cargando...</div>
                    </div>
                    <div className='publicacion__contenido cargando'>
                        <img src='/assets/fotoCargando.jpg'/>
                    </div>
                    <div className='publicacion__footer cargando'>
                        <div className='publicacion__footer__like'>
                        
                        </div>
                        <div className='publicacion__footer__comentario'>
                            
                        </div>
                        <div className='publicacion__footer__compartir'>
                            
                        </div>
                    </div>
                </div>
            </>
        )
    }

    return (
        <>
            <Publicacion url={props.url} like={publicacion.ha_dado_like} publicacion={publicacion} usuario={props.user} id={publicacion.id} foto_perfil={publicacion.foto_perfil} nombre={publicacion.usuario} imagen={publicacion.foto} fecha={publicacion.fecha} id_usuario_publicacion={publicacion.id} segundaRuta={'.'}/>
        </>
    );
}
  
export default PublicacionSola;