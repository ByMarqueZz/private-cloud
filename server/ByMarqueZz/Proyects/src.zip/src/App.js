import './App.css';
import { React, useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Home from "./components/home/home";
import Ranking from "./components/ranking/ranking";
import Footer from "./components/footer/footer";
import Header from "./components/header/header";
import Login from "./components/login/login";
import UploadPublicacion from "./components/uploadPublicacion/uploadPublicacion";
import Historial from "./components/historial/historial";
import Perfil from "./components/perfil/perfil";
import Novedades from "./components/novedades/novedades";
import PublicacionSola from './components/publicacionSola/publicacionSola';
import Comentarios from './components/comentarios/comentarios';
import Register from './components/register/register';
import Admin from './components/admin/admin';
import "./components/fonts/InstagramSansScript.ttf";
import "./components/fonts/InstagramSansScriptBold.ttf";
import Spotify from './components/spotify/spotify';

/**
   * URLS que conectan al servidor de NodeJS
   */
export const url = 'https://jointscounter.com:3090';
// export const url = 'http://localhost:3090';

function App() {
  const [userHash, setUserHash] = useState(null);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [token, setToken] = useState(null);

  /**
   * Comprueba si has iniciado sesión y si es así, guarda el hash en el estado
   * 
   * @param {String} hashPasado 
   */
  function isLogged(hashPasado = null) {
    const cookie = document.cookie.split(';').find(c => c.trim().startsWith('id='));
    if (hashPasado) {
      let hash = hashPasado;
      fetch(url + '/api/user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ hash }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data[0]) {
            setUserHash(hashPasado);
            setUser(data[0]);
            setIsLoading(false);
          }
        })
    } else if (cookie) {
      // coge cookie y partelo en dos por el igual y guarda en una variable lo de la derecha del igual
      let hash = cookie.split('=')[1];
      fetch(url + '/api/user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ hash }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data[0]) {
            setUserHash(cookie.split('=')[1]);
            setUser(data[0]);
            setIsLoading(false);
          } else {
            setUserHash(null)
          }
        })
    } else {
      setUserHash(null);
    }
  }
  /**
   * Comprueba que el usuario esté logueado y si no lo está, redirige a la página de login
   * @param {String, Component} param  
   * @returns {Component}
   */
  const RequireAuth = ({ hash, children }) => {
    // función que comprueba el estado de la sesión y si no existe, redirige a la página de login
    if (hash == null) {
      return <Navigate to="/login" />
    }
    return children
  };

  const RequireAuthSupreme = ({ hash, children }) => {
    // función que comprueba el estado de la sesión y si no existe, redirige a la página de login
    if (hash == null) {
      return <Navigate to="/login" />
    }
    if (user.id == 1 && user.usuario == 'ByMarqueZz') {
      return children
    }
    return <Navigate to="/login" />
  };

  useEffect(() => {
    if (url === 'https://localhost:3090' || url === 'https://192.168.1.136:3090') {
      console.clear();
      console.log('%cEstás en modo desarrollo, localhost', 'color: red; font-size: 50px; font-weight: bold; -webkit-text-stroke: 1px; -webkit-text-stroke-color: #000; font-family: Helvetica; background-color: yellow; padding: 10px;');
    }
    isLogged();
    getToken();
  }, []);

  function getToken() {
    const data = new URLSearchParams({
        grant_type: 'client_credentials',
        client_id: '9476bf345d2c4205872e0f12939cd25f',
        client_secret: 'd9530fa4afe049538a15c2f442bf5962',
    });

    fetch('https://accounts.spotify.com/api/token', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: data,
    })
        .then((response) => response.json())
        .then((data) => {
            setToken(data.access_token);
            setIsLoading(false);
        });
}

  /**
   * Si el usuario no está logueado, solo va a tener acceso a la página de login
   */
  if (isLoading || user == null) {
    return (
      <>
        <BrowserRouter>
          <div className='main'>
            <Routes>
              <Route path="/" element={<Login user={null} functionLogged={isLogged} url={url} />}></Route>
              <Route path="/register" element={<Register url={url}></Register>}></Route>
              **<Route path="*" element={<Login user={null} functionLogged={isLogged} url={url} />}></Route>**
            </Routes>
          </div>
        </BrowserRouter>
      </>
    )
  }

  /**
   * Rutas de la aplicación
   */
  return (
    <>
      <BrowserRouter>
        <Header user={user} />
        <div className='main'>
          <Routes>
            <Route path='login' element={<Login user={user} functionLogged={isLogged} url={url} />}></Route>
            <Route path="/register" element={<Register url={url}></Register>}></Route>
            <Route path="/" element={<RequireAuth hash={userHash}><Home user={user} url={url} /></RequireAuth>}></Route>
            <Route path="/ranking" element={<RequireAuth hash={userHash}><Ranking url={url} urlPeticion={url + '/api/ranking'} /></RequireAuth>}></Route>
            <Route path="/admin" element={<RequireAuthSupreme hash={userHash}><Admin user={user} url={url} /></RequireAuthSupreme>}></Route>
            <Route path="/rankingConcurso" element={<RequireAuth hash={userHash}><Ranking url={url} urlPeticion={url + '/api/concursoActual/2023-04-01/2023-04-16/1000000'} fechaFinal="2023-04-16" /></RequireAuth>}></Route>
            <Route path="/uploadPublicacion" element={<RequireAuth hash={userHash}><UploadPublicacion user={user} url={url} token={token}/></RequireAuth>}></Route>
            <Route path="/historial" element={<RequireAuth hash={userHash}><Historial user={user} url={url} /></RequireAuth>}></Route>
            <Route path="/perfil/:id" element={<RequireAuth hash={userHash}><Perfil user={user} url={url} /></RequireAuth>}></Route>
            <Route path="/novedades" element={<RequireAuth hash={userHash}><Novedades url={url} /></RequireAuth>}></Route>
            <Route path="/publicacion/:id" element={<RequireAuth hash={userHash}><PublicacionSola user={user} url={url} /></RequireAuth>}></Route>
            <Route path="/comentarios/:id" element={<RequireAuth hash={userHash}><Comentarios user={user} url={url} /></RequireAuth>}></Route>
            <Route path='/spotify' element={<RequireAuth hash={userHash}><Spotify user={user} url={url} search={'Perfect girl'} token={token} /></RequireAuth>}></Route>
            **<Route path="*" element={<RequireAuth hash={userHash}><h1>404: Not Found</h1></RequireAuth>}></Route>**
          </Routes>
        </div>
        <Footer user={user} />
      </BrowserRouter>
    </>
  );
}

export default App;
